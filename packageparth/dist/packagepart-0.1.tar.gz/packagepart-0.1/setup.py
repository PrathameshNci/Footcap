from setuptools import setup
setup(name="packagepart",
      version="0.1",
      description="Parth Package",
      author="Parth",
      packages=['packageparth'],
      install_requires=['datetime', 'random2'])